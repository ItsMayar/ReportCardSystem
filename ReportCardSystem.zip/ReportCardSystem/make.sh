#!/usr/bin/env bash

g++ ./Main.cpp ./Person.cpp ./Student.cpp ./ReportCardSystem.cpp ./ReportEntry.cpp ./Util.cpp -o Program
