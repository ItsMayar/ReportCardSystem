NOTE:
Make sure you have g++ installed and in your system path
to be able to use the scripts below.


On Windows:

1. Run "make.cmd"
2. Run "Program.exe" (created by make.cmd)

On Mac/Linux:

1. Run "make.sh"
2. Run "Program" (created by make.sh)
