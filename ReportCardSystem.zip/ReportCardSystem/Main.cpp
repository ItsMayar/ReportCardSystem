#include "ReportCardSystem.h"

int main()
{
    ReportCardSystem rcs;
    return 0;
}
